"""
可视化模块：生成性能对比图表
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class Visualizer:
    """可视化工具类"""
    
    def __init__(self, output_dir: str = 'results/'):
        """
        初始化可视化器
        
        Args:
            output_dir: 输出目录
        """
        self.output_dir = output_dir
        plt.style.use('seaborn-v0_8-darkgrid')
        self.colors = {
            'actual': '#2E86AB',
            'baseline': '#A23B72',
            'ai_model': '#F18F01',
            'error': '#C73E1D'
        }
    
    def plot_predictions_comparison(
        self,
        y_true: np.ndarray,
        y_baseline: np.ndarray,
        y_ai: np.ndarray,
        timestamps: List[datetime] = None,
        title: str = '预测值对比'
    ) -> None:
        """
        绘制预测值对比图
        
        Args:
            y_true: 真实值
            y_baseline: 基线模型预测值
            y_ai: AI模型预测值
            timestamps: 时间戳列表
            title: 图表标题
        """
        fig, axes = plt.subplots(2, 1, figsize=(14, 10))
        
        # 子图1: 预测值对比
        axes[0].plot(y_true, label='真实值', color=self.colors['actual'], linewidth=2)
        axes[0].plot(y_baseline, label='基线模型', color=self.colors['baseline'], linewidth=1.5, alpha=0.8)
        axes[0].plot(y_ai, label='AI模型', color=self.colors['ai_model'], linewidth=1.5, alpha=0.8)
        axes[0].set_ylabel('预测值', fontsize=12)
        axes[0].set_title(title, fontsize=14, fontweight='bold')
        axes[0].legend(loc='best')
        axes[0].grid(True, alpha=0.3)
        
        # 子图2: 误差对比
        error_baseline = y_true - y_baseline
        error_ai = y_true - y_ai
        
        axes[1].plot(error_baseline, label='基线模型误差', color=self.colors['baseline'], linewidth=1)
        axes[1].plot(error_ai, label='AI模型误差', color=self.colors['ai_model'], linewidth=1)
        axes[1].axhline(y=0, color='black', linestyle='--', linewidth=1)
        axes[1].set_ylabel('误差', fontsize=12)
        axes[1].set_xlabel('样本索引', fontsize=12)
        axes[1].legend(loc='best')
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}predictions_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"预测对比图已保存: {self.output_dir}predictions_comparison.png")
    
    def plot_error_distribution(
        self,
        error_baseline: np.ndarray,
        error_ai: np.ndarray,
        title: str = '误差分布对比'
    ) -> None:
        """
        绘制误差分布直方图
        
        Args:
            error_baseline: 基线模型误差
            error_ai: AI模型误差
            title: 图表标题
        """
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # 基线模型误差分布
        axes[0].hist(error_baseline, bins=30, color=self.colors['baseline'], alpha=0.7, edgecolor='black')
        axes[0].axvline(x=0, color='black', linestyle='--', linewidth=2)
        axes[0].axvline(x=np.mean(error_baseline), color='red', linestyle='-', linewidth=2, label=f'均值: {np.mean(error_baseline):.2f}')
        axes[0].set_xlabel('误差', fontsize=12)
        axes[0].set_ylabel('频数', fontsize=12)
        axes[0].set_title('基线模型误差分布', fontsize=14, fontweight='bold')
        axes[0].legend(loc='best')
        axes[0].grid(True, alpha=0.3)
        
        # AI模型误差分布
        axes[1].hist(error_ai, bins=30, color=self.colors['ai_model'], alpha=0.7, edgecolor='black')
        axes[1].axvline(x=0, color='black', linestyle='--', linewidth=2)
        axes[1].axvline(x=np.mean(error_ai), color='red', linestyle='-', linewidth=2, label=f'均值: {np.mean(error_ai):.2f}')
        axes[1].set_xlabel('误差', fontsize=12)
        axes[1].set_ylabel('频数', fontsize=12)
        axes[1].set_title('AI模型误差分布', fontsize=14, fontweight='bold')
        axes[1].legend(loc='best')
        axes[1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}error_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"误差分布图已保存: {self.output_dir}error_distribution.png")
    
    def plot_metrics_comparison(
        self,
        metrics_baseline: Dict[str, float],
        metrics_ai: Dict[str, float],
        title: str = '评估指标对比'
    ) -> None:
        """
        绘制评估指标对比图
        
        Args:
            metrics_baseline: 基线模型指标
            metrics_ai: AI模型指标
            title: 图表标题
        """
        metrics_names = list(metrics_baseline.keys())
        baseline_values = [metrics_baseline[m] for m in metrics_names]
        ai_values = [metrics_ai[m] for m in metrics_names]
        
        x = np.arange(len(metrics_names))
        width = 0.35
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        bars1 = ax.bar(x - width/2, baseline_values, width, label='基线模型', color=self.colors['baseline'])
        bars2 = ax.bar(x + width/2, ai_values, width, label='AI模型', color=self.colors['ai_model'])
        
        ax.set_ylabel('误差值', fontsize=12)
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(metrics_names, fontsize=11)
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3, axis='y')
        
        # 添加数值标签
        for bar in bars1:
            height = bar.get_height()
            ax.annotate(f'{height:.2f}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=10)
        
        for bar in bars2:
            height = bar.get_height()
            ax.annotate(f'{height:.2f}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=10)
        
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}metrics_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"指标对比图已保存: {self.output_dir}metrics_comparison.png")
    
    def plot_feature_importance(
        self,
        feature_importance: pd.DataFrame,
        top_n: int = 20,
        title: str = '特征重要性'
    ) -> None:
        """
        绘制特征重要性图
        
        Args:
            feature_importance: 特征重要性DataFrame
            top_n: 显示前N个特征
            title: 图表标题
        """
        # 排序并取前N个
        importance_sorted = feature_importance.sort_values('importance', ascending=True).tail(top_n)
        
        fig, ax = plt.subplots(figsize=(10, max(6, top_n * 0.3)))
        
        bars = ax.barh(range(len(importance_sorted)), importance_sorted['importance'], color=self.colors['ai_model'])
        ax.set_yticks(range(len(importance_sorted)))
        ax.set_yticklabels(importance_sorted['feature'], fontsize=10)
        ax.set_xlabel('重要性', fontsize=12)
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='x')
        
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}feature_importance.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"特征重要性图已保存: {self.output_dir}feature_importance.png")
    
    def plot_time_series_comparison(
        self,
        y_true: np.ndarray,
        y_baseline: np.ndarray,
        y_ai: np.ndarray,
        timestamps: List[datetime],
        window_size: int = 168,  # 默认显示一周的数据（假设数据粒度为小时）
        title: str = '时间序列预测对比'
    ) -> None:
        """
        绘制时间序列预测对比图（带时间轴）
        
        Args:
            y_true: 真实值
            y_baseline: 基线模型预测值
            y_ai: AI模型预测值
            timestamps: 时间戳列表
            window_size: 显示的数据点数量
            title: 图表标题
        """
        # 只显示最后window_size个点
        if len(y_true) > window_size:
            start_idx = len(y_true) - window_size
        else:
            start_idx = 0
        
        y_true_window = y_true[start_idx:]
        y_baseline_window = y_baseline[start_idx:]
        y_ai_window = y_ai[start_idx:]
        timestamps_window = timestamps[start_idx:]
        
        fig, ax = plt.subplots(figsize=(14, 6))
        
        ax.plot(timestamps_window, y_true_window, label='真实值', color=self.colors['actual'], linewidth=2)
        ax.plot(timestamps_window, y_baseline_window, label='基线模型', color=self.colors['baseline'], linewidth=1.5, alpha=0.8)
        ax.plot(timestamps_window, y_ai_window, label='AI模型', color=self.colors['ai_model'], linewidth=1.5, alpha=0.8)
        
        ax.set_ylabel('预测值', fontsize=12)
        ax.set_xlabel('时间', fontsize=12)
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.legend(loc='best')
        ax.grid(True, alpha=0.3)
        
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(f'{self.output_dir}time_series_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"时间序列对比图已保存: {self.output_dir}time_series_comparison.png")
    
    def generate_full_report(
        self,
        y_true: np.ndarray,
        y_baseline: np.ndarray,
        y_ai: np.ndarray,
        timestamps: List[datetime],
        metrics_baseline: Dict[str, float],
        metrics_ai: Dict[str, float],
        feature_importance: pd.DataFrame = None,
        output_prefix: str = ''
    ) -> None:
        """
        生成完整的可视化报告
        
        Args:
            y_true: 真实值
            y_baseline: 基线模型预测值
            y_ai: AI模型预测值
            timestamps: 时间戳列表
            metrics_baseline: 基线模型指标
            metrics_ai: AI模型指标
            feature_importance: 特征重要性（可选）
            output_prefix: 输出文件前缀
        """
        logger.info("开始生成可视化报告...")
        
        # 1. 预测值对比
        self.plot_predictions_comparison(y_true, y_baseline, y_ai, timestamps)
        
        # 2. 误差分布
        error_baseline = y_true - y_baseline
        error_ai = y_true - y_ai
        self.plot_error_distribution(error_baseline, error_ai)
        
        # 3. 指标对比
        self.plot_metrics_comparison(metrics_baseline, metrics_ai)
        
        # 4. 时间序列对比
        self.plot_time_series_comparison(y_true, y_baseline, y_ai, timestamps)
        
        # 5. 特征重要性（如果有）
        if feature_importance is not None:
            self.plot_feature_importance(feature_importance)
        
        logger.info("可视化报告生成完成")
