"""
评估模块：实现评估指标和基线模型
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from sklearn.metrics import mean_absolute_error, mean_squared_error
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BaselineModel:
    """历史移动平均基线模型"""
    
    def __init__(self):
        """初始化基线模型"""
        self.historical_mean = None
        self.historical_data = None
    
    def fit(self, y: pd.Series, timestamps: pd.Series = None) -> 'BaselineModel':
        """
        拟合基线模型（计算历史平均值）
        
        Args:
            y: 目标值序列
            timestamps: 时间戳序列（可选）
            
        Returns:
            self
        """
        self.historical_data = y.copy()
        self.historical_mean = y.mean()
        
        logger.info(f"基线模型拟合完成: 历史平均值 = {self.historical_mean:.4f}")
        return self
    
    def predict(self, X: pd.DataFrame = None, timestamps: pd.Series = None) -> np.ndarray:
        """
        使用历史平均值进行预测
        
        Args:
            X: 特征矩阵（可选，用于兼容接口）
            timestamps: 预测时间戳（可选）
            
        Returns:
            预测值数组
        """
        if timestamps is not None:
            # 时间序列预测：对于每个时间点，使用其之前的所有历史数据的平均值
            predictions = []
            for i, ts in enumerate(timestamps):
                # 找到该时间点之前的所有历史数据
                if self.historical_data is not None:
                    predictions.append(self.historical_data.iloc[:i+1].mean() if i > 0 else self.historical_mean)
                else:
                    predictions.append(self.historical_mean)
            return np.array(predictions)
        else:
            # 简单预测：返回全局平均值
            return np.full(len(X) if X is not None else 1, self.historical_mean)
    
    def predict_moving_average(self, y_train: pd.Series, y_test_length: int) -> np.ndarray:
        """
        对测试集进行移动平均预测
        
        Args:
            y_train: 训练集目标值
            y_test_length: 测试集长度
            
        Returns:
            预测值数组
        """
        predictions = []
        historical_values = y_train.copy()
        
        for i in range(y_test_length):
            # 使用当前所有历史数据的平均值作为预测
            pred = historical_values.mean()
            predictions.append(pred)
            # 假设添加一个虚拟值（实际应用中可能需要其他策略）
            historical_values = pd.concat([historical_values, pd.Series([pred])])
        
        return np.array(predictions)


class Evaluator:
    """评估指标计算"""
    
    def __init__(self):
        """初始化评估器"""
        self.metrics = {}
    
    def calculate_metrics(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray
    ) -> Dict[str, float]:
        """
        计算所有评估指标
        
        Args:
            y_true: 真实值
            y_pred: 预测值
            
        Returns:
            指标字典
        """
        metrics = {}
        
        # MAE (Mean Absolute Error)
        mae = mean_absolute_error(y_true, y_pred)
        metrics['MAE'] = mae
        
        # MSE (Mean Squared Error)
        mse = mean_squared_error(y_true, y_pred)
        metrics['MSE'] = mse
        
        # RMSE (Root Mean Squared Error)
        rmse = np.sqrt(mse)
        metrics['RMSE'] = rmse
        
        # MAPE (Mean Absolute Percentage Error)
        mape = self._calculate_mape(y_true, y_pred)
        metrics['MAPE'] = mape
        
        # SMAPE (Symmetric Mean Absolute Percentage Error)
        smape = self._calculate_smape(y_true, y_pred)
        metrics['SMAPE'] = smape
        
        self.metrics = metrics
        logger.info(f"评估指标计算完成: {metrics}")
        
        return metrics
    
    def _calculate_mape(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray
    ) -> float:
        """
        计算MAPE
        
        Args:
            y_true: 真实值
            y_pred: 预测值
            
        Returns:
            MAPE值
        """
        mask = y_true != 0
        if not mask.any():
            return np.nan
        
        return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    
    def _calculate_smape(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray
    ) -> float:
        """
        计算SMAPE
        
        Args:
            y_true: 真实值
            y_pred: 预测值
            
        Returns:
            SMAPE值
        """
        denominator = (np.abs(y_true) + np.abs(y_pred)) / 2
        mask = denominator != 0
        
        if not mask.any():
            return np.nan
        
        return np.mean(np.abs(y_true[mask] - y_pred[mask]) / denominator[mask]) * 100
    
    def compare_models(
        self,
        metrics_baseline: Dict[str, float],
        metrics_ai: Dict[str, float]
    ) -> Dict[str, Dict[str, float]]:
        """
        对比两个模型的性能
        
        Args:
            metrics_baseline: 基线模型指标
            metrics_ai: AI模型指标
            
        Returns:
            对比结果字典
        """
        comparison = {}
        
        for metric_name in metrics_baseline.keys():
            if metric_name in metrics_ai:
                baseline_value = metrics_baseline[metric_name]
                ai_value = metrics_ai[metric_name]
                
                improvement = (baseline_value - ai_value) / baseline_value * 100 if baseline_value != 0 else 0
                
                comparison[metric_name] = {
                    'baseline': baseline_value,
                    'ai_model': ai_value,
                    'improvement_percent': improvement
                }
        
        return comparison
    
    def print_report(
        self,
        metrics_baseline: Dict[str, float],
        metrics_ai: Dict[str, float],
        model_name: str = "AI Model"
    ) -> None:
        """
        打印评估报告
        
        Args:
            metrics_baseline: 基线模型指标
            metrics_ai: AI模型指标
            model_name: 模型名称
        """
        comparison = self.compare_models(metrics_baseline, metrics_ai)
        
        print("\n" + "="*70)
        print("模型性能对比报告")
        print("="*70)
        print(f"{'指标':<15} {'基线模型':<15} {model_name:<15} {'提升率':<15}")
        print("-"*70)
        
        for metric_name, values in comparison.items():
            print(f"{metric_name:<15} {values['baseline']:<15.4f} {values['ai_model']:<15.4f} {values['improvement_percent']:<15.2f}%")
        
        print("="*70)
