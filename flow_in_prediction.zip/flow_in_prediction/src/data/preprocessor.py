"""
数据预处理器：数据清洗、标准化和特征编码
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class Preprocessor:
    """数据预处理：清洗、标准化、编码"""
    
    def __init__(self):
        """初始化预处理器"""
        self.numeric_scaler = StandardScaler()
        self.label_encoders = {}
        self.one_hot_encoders = {}
        self.numeric_features = []
        self.categorical_features = []
        self.is_fitted = False
    
    def fit(
        self,
        df: pd.DataFrame,
        target_column: str = 'target_value',
        numeric_features: Optional[List[str]] = None,
        categorical_features: Optional[List[str]] = None
    ) -> 'Preprocessor':
        """
        拟合预处理器
        
        Args:
            df: 输入DataFrame
            target_column: 目标列名
            numeric_features: 数值特征列表，None则自动检测
            categorical_features: 类别特征列表，None则自动检测
            
        Returns:
            self
        """
        # 分离特征和目标
        if target_column in df.columns:
            self.feature_columns = [col for col in df.columns if col != target_column]
        else:
            self.feature_columns = df.columns.tolist()
        
        # 自动检测特征类型
        if numeric_features is None:
            self.numeric_features = df.select_dtypes(include=[np.number]).columns.tolist()
            if target_column in self.numeric_features:
                self.numeric_features.remove(target_column)
        else:
            self.numeric_features = numeric_features
        
        if categorical_features is None:
            self.categorical_features = df.select_dtypes(include=['object', 'category']).columns.tolist()
        else:
            self.categorical_features = categorical_features
        
        # 拟合数值特征标准化器
        if len(self.numeric_features) > 0:
            self.numeric_scaler.fit(df[self.numeric_features].fillna(0))
        
        # 拟合类别特征编码器
        for col in self.categorical_features:
            if col in df.columns:
                self.label_encoders[col] = LabelEncoder()
                self.label_encoders[col].fit(df[col].fillna('unknown'))
        
        self.is_fitted = True
        logger.info(f"预处理器拟合完成: {len(self.numeric_features)} 个数值特征, {len(self.categorical_features)} 个类别特征")
        
        return self
    
    def transform(
        self,
        df: pd.DataFrame,
        target_column: Optional[str] = None
    ) -> Tuple[pd.DataFrame, Optional[pd.Series]]:
        """
        转换数据
        
        Args:
            df: 输入DataFrame
            target_column: 目标列名（可选）
            
        Returns:
            转换后的特征DataFrame和可选的目标Series
        """
        if not self.is_fitted:
            raise ValueError("预处理器尚未拟合，请先调用fit()方法")
        
        # 选择特征列
        if target_column and target_column in df.columns:
            X = df[self.feature_columns].copy()
            y = df[target_column].copy()
        else:
            X = df[self.feature_columns].copy()
            y = None
        
        # 数值特征处理
        if len(self.numeric_features) > 0:
            X_numeric = X[self.numeric_features].fillna(0)
            X_numeric_scaled = self.numeric_scaler.transform(X_numeric)
            X_numeric_df = pd.DataFrame(
                X_numeric_scaled,
                columns=[f"{col}_scaled" for col in self.numeric_features],
                index=X.index
            )
        else:
            X_numeric_df = pd.DataFrame(index=X.index)
        
        # 类别特征处理
        X_categorical_list = []
        for col in self.categorical_features:
            if col in X.columns:
                X_col = X[col].fillna('unknown')
                X_col_encoded = self.label_encoders[col].transform(X_col)
                X_categorical_list.append(pd.Series(X_col_encoded, name=col, index=X.index))
        
        if len(X_categorical_list) > 0:
            X_categorical_df = pd.concat(X_categorical_list, axis=1)
        else:
            X_categorical_df = pd.DataFrame(index=X.index)
        
        # 合并所有特征
        X_processed = pd.concat([X_numeric_df, X_categorical_df], axis=1)
        
        logger.info(f"数据转换完成: {X_processed.shape[0]} 行, {X_processed.shape[1]} 列")
        
        return X_processed, y
    
    def fit_transform(
        self,
        df: pd.DataFrame,
        target_column: str = 'target_value'
    ) -> Tuple[pd.DataFrame, pd.Series]:
        """
        拟合并转换数据
        
        Args:
            df: 输入DataFrame
            target_column: 目标列名
            
        Returns:
            转换后的特征DataFrame和目标Series
        """
        self.fit(df, target_column)
        return self.transform(df, target_column)
    
    def inverse_transform_numeric(self, X_scaled: np.ndarray) -> np.ndarray:
        """
        反标准化数值特征
        
        Args:
            X_scaled: 标准化后的数值特征
            
        Returns:
            反标准化后的数值特征
        """
        if not self.is_fitted:
            raise ValueError("预处理器尚未拟合")
        
        return self.numeric_scaler.inverse_transform(X_scaled)
    
    def get_feature_names(self) -> List[str]:
        """
        获取处理后的特征名称
        
        Returns:
            特征名称列表
        """
        numeric_names = [f"{col}_scaled" for col in self.numeric_features]
        categorical_names = self.categorical_features
        return numeric_names + categorical_names
