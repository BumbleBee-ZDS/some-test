"""
数据加载器：从数据库提取历史数据
"""

import pandas as pd
import pyodbc
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataLoader:
    """从数据库加载Lot移动历史数据"""
    
    def __init__(self, db_config: Dict[str, str]):
        """
        初始化数据库连接配置
        
        Args:
            db_config: 数据库配置字典，包含host, port, name, user, password
        """
        self.db_config = db_config
        self.connection = None
    
    def connect(self) -> None:
        """建立数据库连接"""
        try:
            conn_str = (
                f"DRIVER={{ODBC Driver 17 for SQL Server}};"
                f"SERVER={self.db_config['host']},{self.db_config['port']};"
                f"DATABASE={self.db_config['name']};"
                f"UID={self.db_config['user']};"
                f"PWD={self.db_config['password']}"
            )
            self.connection = pyodbc.connect(conn_str)
            logger.info("数据库连接成功")
        except Exception as e:
            logger.error(f"数据库连接失败: {e}")
            raise
    
    def close(self) -> None:
        """关闭数据库连接"""
        if self.connection:
            self.connection.close()
            logger.info("数据库连接已关闭")
    
    def load_lot_history(
        self,
        start_date: str,
        end_date: str,
        sites: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        加载Lot移动历史数据
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            sites: 指定的工艺站点列表，None表示所有站点
            
        Returns:
            DataFrame包含Lot移动记录
        """
        query = """
            SELECT 
                lot_id,
                site,
                product_type,
                route,
                priority,
                layer,
                batch_size,
                arrival_timestamp,
                departure_timestamp,
                hold_duration,
                tool_id,
                recipe,
                tool_state,
                time_since_last_pm
            FROM lot_movement_history
            WHERE arrival_timestamp >= ?
                AND arrival_timestamp <= ?
        """
        
        params = [start_date, end_date]
        
        if sites:
            placeholders = ','.join(['?' for _ in sites])
            query += f" AND site IN ({placeholders})"
            params.extend(sites)
        
        query += " ORDER BY lot_id, arrival_timestamp"
        
        try:
            df = pd.read_sql(query, self.connection, params=params)
            logger.info(f"加载了 {len(df)} 条Lot移动记录")
            return df
        except Exception as e:
            logger.error(f"查询数据失败: {e}")
            raise
    
    def load_queue_state(
        self,
        timestamp: datetime,
        target_site: str
    ) -> pd.DataFrame:
        """
        加载指定时刻的队列状态
        
        Args:
            timestamp: 查询时刻
            target_site: 目标站点
            
        Returns:
            队列中Lot的信息
        """
        query = """
            SELECT 
                lot_id,
                priority,
                estimated_processing_time,
                hold_status,
                is_hot_lot,
                is_vip,
                is_eng_lot
            FROM current_queue
            WHERE site = ?
                AND created_timestamp <= ?
            ORDER BY priority, created_timestamp
        """
        
        try:
            df = pd.read_sql(
                query, 
                self.connection, 
                params=[target_site, timestamp]
            )
            return df
        except Exception as e:
            logger.error(f"查询队列状态失败: {e}")
            raise
    
    def load_tool_status(
        self,
        start_date: str,
        end_date: str,
        tool_ids: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        加载机台状态历史
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            tool_ids: 机台ID列表
            
        Returns:
            机台状态记录
        """
        query = """
            SELECT 
                tool_id,
                timestamp,
                tool_state,
                current_recipe,
                time_since_last_pm,
                pm_schedule
            FROM tool_status_history
            WHERE timestamp >= ?
                AND timestamp <= ?
        """
        
        params = [start_date, end_date]
        
        if tool_ids:
            placeholders = ','.join(['?' for _ in tool_ids])
            query += f" AND tool_id IN ({placeholders})"
            params.extend(tool_ids)
        
        try:
            df = pd.read_sql(query, self.connection, params=params)
            return df
        except Exception as e:
            logger.error(f"查询机台状态失败: {e}")
            raise
    
    def load_mask_info(
        self,
        start_date: str,
        end_date: str
    ) -> pd.DataFrame:
        """
        加载Mask管理信息
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            Mask状态记录
        """
        query = """
            SELECT 
                lot_id,
                mask_id,
                mask_status,
                mask_change_duration,
                expected_available_time
            FROM mask_management_history
            WHERE timestamp >= ?
                AND timestamp <= ?
        """
        
        try:
            df = pd.read_sql(query, self.connection, params=[start_date, end_date])
            return df
        except Exception as e:
            logger.error(f"查询Mask信息失败: {e}")
            raise
    
    def load_special_dispatch(
        self,
        start_date: str,
        end_date: str
    ) -> pd.DataFrame:
        """
        加载特殊派工事件
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            特殊派工记录
        """
        query = """
            SELECT 
                lot_id,
                dispatch_type,
                priority_weight,
                dispatch_time,
                effective_duration
            FROM special_dispatch_history
            WHERE dispatch_time >= ?
                AND dispatch_time <= ?
        """
        
        try:
            df = pd.read_sql(query, self.connection, params=[start_date, end_date])
            return df
        except Exception as e:
            logger.error(f"查询特殊派工失败: {e}")
            raise
