"""
特征工程模块：从原始数据构造预测特征
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FeatureEngineer:
    """特征工程：构造预测模型所需的特征"""
    
    def __init__(self):
        """初始化特征工程器"""
        self.feature_definitions = {}
    
    def extract_lot_features(
        self,
        lot_history: pd.DataFrame,
        queue_state: pd.DataFrame,
        tool_status: pd.DataFrame,
        mask_info: pd.DataFrame,
        special_dispatch: pd.DataFrame,
        prediction_time: datetime,
        target_lot_id: str,
        target_site: str
    ) -> Dict[str, any]:
        """
        为特定Lot在特定时刻提取特征
        
        Args:
            lot_history: Lot移动历史
            queue_state: 队列状态
            tool_status: 机台状态
            mask_info: Mask信息
            special_dispatch: 特殊派工事件
            prediction_time: 预测时刻
            target_lot_id: 目标Lot ID
            target_site: 目标站点
            
        Returns:
            特征字典
        """
        features = {}
        
        # Lot基础属性特征
        features.update(self._extract_lot_attributes(
            lot_history, target_lot_id, target_site
        ))
        
        # 历史移动时序特征
        features.update(self._extract_historical_timing(
            lot_history, target_lot_id, target_site
        ))
        
        # 队列状态特征
        features.update(self._extract_queue_features(
            queue_state, target_lot_id, target_site
        ))
        
        # 机台状态特征
        features.update(self._extract_tool_features(
            tool_status, target_site, prediction_time
        ))
        
        # Mask管理特征
        features.update(self._extract_mask_features(
            mask_info, target_lot_id, target_site
        ))
        
        # 特殊派工特征
        features.update(self._extract_dispatch_features(
            special_dispatch, target_lot_id
        ))
        
        # 时空关系特征
        features.update(self._extract_temporal_features(
            lot_history, target_lot_id, target_site, prediction_time
        ))
        
        return features
    
    def _extract_lot_attributes(
        self,
        lot_history: pd.DataFrame,
        target_lot_id: str,
        target_site: str
    ) -> Dict[str, any]:
        """提取Lot基础属性特征"""
        lot_data = lot_history[lot_history['lot_id'] == target_lot_id]
        
        if len(lot_data) == 0:
            return {
                'lot_priority': 0,
                'product_type': 'unknown',
                'route': 'unknown',
                'layer': 0,
                'batch_size': 1
            }
        
        latest_record = lot_data.iloc[-1]
        
        return {
            'lot_priority': latest_record.get('priority', 0),
            'product_type': latest_record.get('product_type', 'unknown'),
            'route': latest_record.get('route', 'unknown'),
            'layer': latest_record.get('layer', 0),
            'batch_size': latest_record.get('batch_size', 1)
        }
    
    def _extract_historical_timing(
        self,
        lot_history: pd.DataFrame,
        target_lot_id: str,
        target_site: str
    ) -> Dict[str, any]:
        """提取历史移动时序特征"""
        lot_data = lot_history[lot_history['lot_id'] == target_lot_id].copy()
        
        if len(lot_data) == 0:
            return {
                'historical_move_rate': 0,
                'product_step_avg_time': 0,
                'historical_hold_frequency': 0
            }
        
        # 计算每个站点的处理时间
        lot_data['processing_time'] = (
            lot_data['departure_timestamp'] - lot_data['arrival_timestamp']
        ).dt.total_seconds() / 3600
        
        # 过滤到目标站点的记录
        site_records = lot_data[lot_data['site'] == target_site]
        
        if len(site_records) > 0:
            avg_processing_time = site_records['processing_time'].mean()
        else:
            # 使用该产品在其他站点的平均移动时间作为代理
            other_site_times = lot_data['processing_time']
            avg_processing_time = other_site_times.mean() if len(other_site_times) > 0 else 0
        
        # 计算历史移动节拍（从上一个站点到当前站点的时间）
        lot_data = lot_data.sort_values('arrival_timestamp')
        lot_data['move_time'] = lot_data['arrival_timestamp'].diff().dt.total_seconds() / 3600
        move_times = lot_data['move_time'].dropna()
        
        historical_move_rate = move_times.mean() if len(move_times) > 0 else 0
        
        # 历史挡货频率
        hold_records = lot_data[lot_data['hold_duration'] > 0]
        historical_hold_frequency = len(hold_records) / len(lot_data) if len(lot_data) > 0 else 0
        
        return {
            'historical_move_rate': historical_move_rate,
            'product_step_avg_time': avg_processing_time,
            'historical_hold_frequency': historical_hold_frequency
        }
    
    def _extract_queue_features(
        self,
        queue_state: pd.DataFrame,
        target_lot_id: str,
        target_site: str
    ) -> Dict[str, any]:
        """提取队列状态特征"""
        if len(queue_state) == 0:
            return {
                'queue_length': 0,
                'queue_workload': 0,
                'high_priority_in_queue': 0
            }
        
        queue_data = queue_state[queue_state['site'] == target_site] if 'site' in queue_state.columns else queue_state
        
        queue_length = len(queue_data)
        queue_workload = queue_data.get('estimated_processing_time', 0).sum() if 'estimated_processing_time' in queue_data.columns else 0
        
        target_lot_priority = queue_state[queue_state['lot_id'] == target_lot_id]['priority'].values
        target_lot_priority = target_lot_priority[0] if len(target_lot_priority) > 0 else 0
        
        high_priority_in_queue = len(
            queue_data[queue_data['priority'] < target_lot_priority]
        ) if 'priority' in queue_data.columns else 0
        
        return {
            'queue_length': queue_length,
            'queue_workload': queue_workload,
            'high_priority_in_queue': high_priority_in_queue
        }
    
    def _extract_tool_features(
        self,
        tool_status: pd.DataFrame,
        target_site: str,
        prediction_time: datetime
    ) -> Dict[str, any]:
        """提取机台状态特征"""
        tool_data = tool_status[tool_status['tool_id'] == target_site].copy() if 'tool_id' in tool_status.columns else tool_status
        
        if len(tool_data) == 0:
            return {
                'tool_state': 0,
                'time_since_last_pm': 0,
                'scheduled_pi_run_in_next_h': 0
            }
        
        # 找到最接近预测时刻的状态
        tool_data['time_diff'] = abs((tool_data['timestamp'] - prediction_time).dt.total_seconds())
        closest_record = tool_data.loc[tool_data['time_diff'].idxmin()]
        
        # 机台状态编码：0-正常，1-机况，2-PM，3-故障
        state_mapping = {
            'production': 0,
            'idle': 0,
            'maintenance': 1,
            'pm': 2,
            'fault': 3
        }
        tool_state = state_mapping.get(closest_record.get('tool_state', 'production'), 0)
        
        time_since_last_pm = closest_record.get('time_since_last_pm', 0)
        
        # 检查未来是否有Pi Run计划
        scheduled_pi_run = 0
        if 'pm_schedule' in closest_record and closest_record['pm_schedule']:
            pm_schedule = closest_record['pm_schedule']
            if isinstance(pm_schedule, list):
                for schedule in pm_schedule:
                    if schedule.get('start_time', datetime.max) <= prediction_time + timedelta(hours=24):
                        scheduled_pi_run = 1
                        break
        
        return {
            'tool_state': tool_state,
            'time_since_last_pm': time_since_last_pm,
            'scheduled_pi_run_in_next_h': scheduled_pi_run
        }
    
    def _extract_mask_features(
        self,
        mask_info: pd.DataFrame,
        target_lot_id: str,
        target_site: str
    ) -> Dict[str, any]:
        """提取Mask管理特征"""
        mask_data = mask_info[mask_info['lot_id'] == target_lot_id].copy()
        
        if len(mask_data) == 0:
            return {
                'mask_ready_flag': 0,
                'mask_change_duration': 0
            }
        
        latest_mask = mask_data.iloc[-1]
        
        mask_ready = 1 if latest_mask.get('mask_status') == 'ready' else 0
        mask_change_duration = latest_mask.get('mask_change_duration', 0)
        
        return {
            'mask_ready_flag': mask_ready,
            'mask_change_duration': mask_change_duration
        }
    
    def _extract_dispatch_features(
        self,
        special_dispatch: pd.DataFrame,
        target_lot_id: str
    ) -> Dict[str, any]:
        """提取特殊派工特征"""
        dispatch_data = special_dispatch[special_dispatch['lot_id'] == target_lot_id].copy()
        
        if len(dispatch_data) == 0:
            return {
                'is_hot_lot': 0,
                'is_vip_lot': 0,
                'is_eng_lot': 0,
                'dispatch_priority_weight': 1
            }
        
        latest_dispatch = dispatch_data.iloc[-1]
        
        dispatch_type = latest_dispatch.get('dispatch_type', '')
        
        return {
            'is_hot_lot': 1 if 'hot' in dispatch_type.lower() else 0,
            'is_vip_lot': 1 if 'vip' in dispatch_type.lower() else 0,
            'is_eng_lot': 1 if 'eng' in dispatch_type.lower() else 0,
            'dispatch_priority_weight': latest_dispatch.get('priority_weight', 1)
        }
    
    def _extract_temporal_features(
        self,
        lot_history: pd.DataFrame,
        target_lot_id: str,
        target_site: str,
        prediction_time: datetime
    ) -> Dict[str, any]:
        """提取时空关系特征"""
        lot_data = lot_history[lot_history['lot_id'] == target_lot_id].copy()
        
        if len(lot_data) == 0:
            return {
                'estimated_arrival_time_naive': 0,
                'time_to_window_start': 0
            }
        
        # 基于历史平均的预估到达时间
        site_records = lot_data[lot_data['site'] == target_site]
        
        if len(site_records) > 0:
            avg_processing_time = site_records['processing_time'].mean() if 'processing_time' in site_records.columns else 0
            estimated_arrival_time_naive = avg_processing_time
        else:
            # 使用该产品在其他站点的平均处理时间
            other_times = lot_data['processing_time'] if 'processing_time' in lot_data.columns else []
            estimated_arrival_time_naive = np.mean(other_times) if len(other_times) > 0 else 0
        
        # 距离可开始派工窗口的时间
        latest_record = lot_data.iloc[-1]
        latest_arrival = latest_record['arrival_timestamp']
        
        # 假设需要在当前时间后某个时间窗口开始派工
        time_to_window_start = (prediction_time - latest_arrival).total_seconds() / 3600
        
        return {
            'estimated_arrival_time_naive': estimated_arrival_time_naive,
            'time_to_window_start': max(0, time_to_window_start)
        }
    
    def create_feature_dataframe(
        self,
        predictions: List[Dict[str, any]]
    ) -> pd.DataFrame:
        """
        将特征字典列表转换为DataFrame
        
        Args:
            predictions: 特征字典列表
            
        Returns:
            DataFrame格式的特征矩阵
        """
        return pd.DataFrame(predictions)
