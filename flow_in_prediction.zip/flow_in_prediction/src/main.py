"""
主程序：Lot到站时间预测系统
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import logging
import yaml
import os

from src.data.data_loader import DataLoader
from src.data.feature_engineer import FeatureEngineer
from src.data.preprocessor import Preprocessor
from src.evaluation.evaluator import Evaluator, BaselineModel
from src.models.models import LightGBMModel, XGBoostModel, ModelTrainer
from src.visualization.visualization import Visualizer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class FlowInPredictor:
    """Lot到站时间预测器"""
    
    def __init__(self, config_path: str = 'config.yaml'):
        """
        初始化预测器
        
        Args:
            config_path: 配置文件路径
        """
        # 加载配置
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        # 创建输出目录
        self.output_dir = self.config['paths']['results']
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 初始化组件
        self.data_loader = DataLoader(self.config['data']['database'])
        self.feature_engineer = FeatureEngineer()
        self.preprocessor = Preprocessor()
        self.evaluator = Evaluator()
        self.baseline_model = BaselineModel()
        self.model_trainer = ModelTrainer()
        self.visualizer = Visualizer(self.output_dir)
        
        logger.info("FlowInPredictor初始化完成")
    
    def load_data(
        self,
        start_date: str = None,
        end_date: str = None
    ) -> pd.DataFrame:
        """
        加载数据
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            Lot移动历史数据
        """
        if start_date is None:
            start_date = self.config['data']['time_range']['training_start']
        if end_date is None:
            end_date = self.config['data']['time_range']['training_end']
        
        self.data_loader.connect()
        
        try:
            df = self.data_loader.load_lot_history(start_date, end_date)
            return df
        finally:
            self.data_loader.close()
    
    def prepare_data(
        self,
        lot_history: pd.DataFrame,
        test_size: float = 0.2
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
        """
        准备训练和测试数据
        
        Args:
            lot_history: Lot移动历史
            test_size: 测试集比例
            
        Returns:
            训练集和测试集
        """
        # 创建目标变量：处理时间
        lot_history = lot_history.copy()
        lot_history['processing_time'] = (
            lot_history['departure_timestamp'] - lot_history['arrival_timestamp']
        ).dt.total_seconds() / 3600
        
        # 按时间排序
        lot_history = lot_history.sort_values('arrival_timestamp')
        
        # 分离特征和目标
        target = 'processing_time'
        
        # 按时间划分训练集和测试集
        split_idx = int(len(lot_history) * (1 - test_size))
        
        train_df = lot_history.iloc[:split_idx].copy()
        test_df = lot_history.iloc[split_idx:].copy()
        
        # 提取目标值
        y_train = train_df[target]
        y_test = test_df[target]
        
        logger.info(f"数据准备完成: 训练集 {len(train_df)} 样本, 测试集 {len(test_df)} 样本")
        
        return train_df, test_df, y_train, y_test
    
    def extract_features_for_test(
        self,
        train_df: pd.DataFrame,
        test_df: pd.DataFrame,
        y_test: pd.Series
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        为测试集提取特征
        
        Args:
            train_df: 训练集
            test_df: 测试集
            y_test: 测试集目标值
            
        Returns:
            训练特征和测试特征
        """
        # 这里简化处理，实际应用中需要为每个测试样本提取完整的特征
        # 包括队列状态、机台状态、Mask信息等
        
        # 示例：只使用历史处理时间作为特征
        train_features = train_df[['processing_time']].copy()
        test_features = test_df[['processing_time']].copy()
        
        # 重命名特征
        train_features.columns = ['historical_processing_time']
        test_features.columns = ['historical_processing_time']
        
        return train_features, test_features
    
    def train_baseline_model(
        self,
        y_train: pd.Series,
        y_test: pd.Series
    ) -> np.ndarray:
        """
        训练基线模型并预测
        
        Args:
            y_train: 训练集目标值
            y_test: 测试集目标值
            
        Returns:
            基线模型预测值
        """
        # 拟合基线模型
        self.baseline_model.fit(y_train)
        
        # 预测
        y_pred_baseline = self.baseline_model.predict_moving_average(
            y_train, len(y_test)
        )
        
        # 计算指标
        metrics_baseline = self.evaluator.calculate_metrics(y_test.values, y_pred_baseline)
        
        logger.info(f"基线模型完成 - MAE: {metrics_baseline['MAE']:.4f}")
        
        return y_pred_baseline, metrics_baseline
    
    def train_ai_model(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_test: pd.DataFrame,
        y_test: pd.Series
    ) -> Tuple[np.ndarray, object, Dict[str, float]]:
        """
        训练AI模型并预测
        
        Args:
            X_train: 训练特征
            y_train: 训练目标
            X_test: 测试特征
            y_test: 测试目标
            
        Returns:
            AI模型预测值、训练好的模型、评估指标
        """
        # 数据预处理
        X_train_processed, _ = self.preprocessor.fit_transform(X_train)
        X_test_processed, _ = self.preprocessor.transform(X_test)
        
        # 划分验证集
        X_tr, X_val, y_tr, y_val = train_test_split(
            X_train_processed, y_train, test_size=0.2, random_state=42
        )
        
        # 训练模型
        models = self.model_trainer.train_all_models(X_tr, y_tr, X_val, y_val)
        
        # 使用最佳模型预测
        best_model = self.model_trainer.best_model
        y_pred_ai = best_model.predict(X_test_processed)
        
        # 计算指标
        metrics_ai = self.evaluator.calculate_metrics(y_test.values, y_pred_ai)
        
        logger.info(f"AI模型完成 - MAE: {metrics_ai['MAE']:.4f}")
        
        return y_pred_ai, best_model, metrics_ai
    
    def generate_report(
        self,
        y_test: pd.Series,
        y_pred_baseline: np.ndarray,
        y_pred_ai: np.ndarray,
        metrics_baseline: Dict[str, float],
        metrics_ai: Dict[str, float],
        best_model: object = None
    ) -> None:
        """
        生成评估报告和可视化
        
        Args:
            y_test: 测试集真实值
            y_pred_baseline: 基线模型预测值
            y_pred_ai: AI模型预测值
            metrics_baseline: 基线模型指标
            metrics_ai: AI模型指标
            best_model: 最佳模型（可选）
        """
        # 打印指标对比
        self.evaluator.print_report(metrics_baseline, metrics_ai)
        
        # 获取时间戳
        timestamps = y_test.index.tolist()
        
        # 生成可视化
        feature_importance = None
        if best_model:
            try:
                feature_importance = best_model.get_feature_importance()
            except:
                pass
        
        self.visualizer.generate_full_report(
            y_test.values,
            y_pred_baseline,
            y_pred_ai,
            timestamps,
            metrics_baseline,
            metrics_ai,
            feature_importance
        )
    
    def run(
        self,
        start_date: str = None,
        end_date: str = None
    ) -> None:
        """
        运行完整的预测流程
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
        """
        logger.info("="*60)
        logger.info("Lot到站时间预测系统 - 开始运行")
        logger.info("="*60)
        
        # 1. 加载数据
        logger.info("\n[1/5] 加载数据...")
        lot_history = self.load_data(start_date, end_date)
        
        # 2. 准备数据
        logger.info("\n[2/5] 准备数据...")
        train_df, test_df, y_train, y_test = self.prepare_data(lot_history)
        
        # 3. 提取特征
        logger.info("\n[3/5] 提取特征...")
        X_train, X_test = self.extract_features_for_test(train_df, test_df, y_test)
        
        # 4. 训练模型
        logger.info("\n[4/5] 训练模型...")
        
        # 训练基线模型
        y_pred_baseline, metrics_baseline = self.train_baseline_model(y_train, y_test)
        
        # 训练AI模型
        y_pred_ai, best_model, metrics_ai = self.train_ai_model(
            X_train, y_train, X_test, y_test
        )
        
        # 5. 生成报告
        logger.info("\n[5/5] 生成报告...")
        self.generate_report(
            y_test, y_pred_baseline, y_pred_ai,
            metrics_baseline, metrics_ai, best_model
        )
        
        logger.info("="*60)
        logger.info("Lot到站时间预测系统 - 运行完成")
        logger.info("="*60)


def main():
    """主函数"""
    predictor = FlowInPredictor('config.yaml')
    predictor.run()


if __name__ == '__main__':
    main()
