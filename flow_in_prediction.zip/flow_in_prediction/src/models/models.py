"""
模型训练模块：实现LightGBM和XGBoost模型
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_absolute_error, mean_squared_error
import lightgbm as lgb
import xgboost as xgb
import logging
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BaseModel:
    """模型基类"""
    
    def __init__(self, model_name: str, params: Dict = None):
        """
        初始化模型
        
        Args:
            model_name: 模型名称
            params: 模型参数
        """
        self.model_name = model_name
        self.params = params or {}
        self.model = None
        self.feature_names = None
        self.is_fitted = False
    
    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        X_val: pd.DataFrame = None,
        y_val: pd.Series = None
    ) -> 'BaseModel':
        """
        训练模型
        
        Args:
            X: 训练特征
            y: 训练目标
            X_val: 验证特征（可选）
            y_val: 验证目标（可选）
            
        Returns:
            self
        """
        self.feature_names = X.columns.tolist()
        logger.info(f"开始训练模型: {self.model_name}")
        logger.info(f"训练数据: {X.shape[0]} 样本, {X.shape[1]} 特征")
        
        return self
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        预测
        
        Args:
            X: 特征
            
        Returns:
            预测值
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用fit()方法")
        
        return self.model.predict(X)
    
    def get_feature_importance(self) -> pd.DataFrame:
        """
        获取特征重要性
        
        Returns:
            特征重要性DataFrame
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': self.model.feature_importance_
        })
        importance = importance.sort_values('importance', ascending=False)
        
        return importance
    
    def save(self, filepath: str) -> None:
        """
        保存模型
        
        Args:
            filepath: 保存路径
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        model_data = {
            'model_name': self.model_name,
            'params': self.params,
            'feature_names': self.feature_names,
            'is_fitted': self.is_fitted
        }
        
        with open(filepath, 'w') as f:
            json.dump(model_data, f)
        
        logger.info(f"模型已保存到: {filepath}")
    
    def load(self, filepath: str) -> 'BaseModel':
        """
        加载模型
        
        Args:
            filepath: 模型文件路径
            
        Returns:
            self
        """
        with open(filepath, 'r') as f:
            model_data = json.load(f)
        
        self.model_name = model_data['model_name']
        self.params = model_data['params']
        self.feature_names = model_data['feature_names']
        self.is_fitted = model_data['is_fitted']
        
        logger.info(f"模型已加载: {filepath}")
        return self


class LightGBMModel(BaseModel):
    """LightGBM模型"""
    
    def __init__(self, params: Dict = None):
        """
        初始化LightGBM模型
        
        Args:
            params: 模型参数
        """
        default_params = {
            'objective': 'regression',
            'metric': 'mae',
            'num_leaves': 31,
            'learning_rate': 0.05,
            'n_estimators': 100,
            'feature_fraction': 0.8,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'seed': 42,
            'verbose': -1
        }
        
        if params:
            default_params.update(params)
        
        super().__init__('LightGBM', default_params)
        self.model = None
    
    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        X_val: pd.DataFrame = None,
        y_val: pd.Series = None
    ) -> 'LightGBMModel':
        """
        训练LightGBM模型
        
        Args:
            X: 训练特征
            y: 训练目标
            X_val: 验证特征（可选）
            y_val: 验证目标（可选）
            
        Returns:
            self
        """
        super().fit(X, y, X_val, y_val)
        
        # 创建数据集
        train_data = lgb.Dataset(X, label=y)
        
        # 如果有验证集
        eval_sets = None
        if X_val is not None and y_val is not None:
            eval_data = lgb.Dataset(X_val, label=y_val, reference=train_data)
            eval_sets = [train_data, eval_data]
        
        # 训练模型
        self.model = lgb.train(
            self.params,
            train_data,
            valid_sets=eval_sets,
            verbose_eval=10
        )
        
        self.is_fitted = True
        logger.info(f"LightGBM模型训练完成")
        
        return self
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        预测
        
        Args:
            X: 特征
            
        Returns:
            预测值
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用fit()方法")
        
        return self.model.predict(X)
    
    def get_feature_importance(self) -> pd.DataFrame:
        """
        获取特征重要性
        
        Returns:
            特征重要性DataFrame
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        importance = self.model.feature_importance()
        
        feature_importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': importance
        })
        feature_importance = feature_importance.sort_values('importance', ascending=False)
        
        return feature_importance


class XGBoostModel(BaseModel):
    """XGBoost模型"""
    
    def __init__(self, params: Dict = None):
        """
        初始化XGBoost模型
        
        Args:
            params: 模型参数
        """
        default_params = {
            'objective': 'reg:linear',
            'eval_metric': 'mae',
            'max_depth': 6,
            'learning_rate': 0.05,
            'n_estimators': 100,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'seed': 42
        }
        
        if params:
            default_params.update(params)
        
        super().__init__('XGBoost', default_params)
        self.model = None
    
    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        X_val: pd.DataFrame = None,
        y_val: pd.Series = None
    ) -> 'XGBoostModel':
        """
        训练XGBoost模型
        
        Args:
            X: 训练特征
            y: 训练目标
            X_val: 验证特征（可选）
            y_val: 验证目标（可选）
            
        Returns:
            self
        """
        super().fit(X, y, X_val, y_val)
        
        # 创建DMatrix
        train_matrix = xgb.DMatrix(X, label=y)
        
        # 如果有验证集
        eval_lists = None
        if X_val is not None and y_val is not None:
            val_matrix = xgb.DMatrix(X_val, label=y_val)
            eval_lists = [(train_matrix, 'train'), (val_matrix, 'val')]
        
        # 训练模型
        self.model = xgb.train(
            self.params,
            train_matrix,
            evals=eval_lists,
            verbose_eval=10
        )
        
        self.is_fitted = True
        logger.info(f"XGBoost模型训练完成")
        
        return self
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        预测
        
        Args:
            X: 特征
            
        Returns:
            预测值
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用fit()方法")
        
        dmatrix = xgb.DMatrix(X)
        return self.model.predict(dmatrix)
    
    def get_feature_importance(self) -> pd.DataFrame:
        """
        获取特征重要性
        
        Returns:
            特征重要性DataFrame
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        importance_dict = self.model.get_score(importance_type='weight')
        
        feature_importance = pd.DataFrame([
            {'feature': k, 'importance': v}
            for k, v in importance_dict.items()
        ])
        feature_importance = feature_importance.sort_values('importance', ascending=False)
        
        return feature_importance


class ModelTrainer:
    """模型训练器"""
    
    def __init__(self):
        """初始化训练器"""
        self.models = {}
        self.best_model = None
        self.best_metrics = {}
    
    def train_model(
        self,
        model: BaseModel,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series
    ) -> BaseModel:
        """
        训练单个模型
        
        Args:
            model: 模型对象
            X_train: 训练特征
            y_train: 训练目标
            X_val: 验证特征
            y_val: 验证目标
            
        Returns:
            训练后的模型
        """
        model.fit(X_train, y_train, X_val, y_val)
        
        # 验证集预测
        y_pred = model.predict(X_val)
        
        # 计算指标
        mae = mean_absolute_error(y_val, y_pred)
        rmse = np.sqrt(mean_squared_error(y_val, y_pred))
        
        logger.info(f"{model.model_name} - Val MAE: {mae:.4f}, RMSE: {rmse:.4f}")
        
        self.models[model.model_name] = {
            'model': model,
            'metrics': {'mae': mae, 'rmse': rmse}
        }
        
        return model
    
    def find_best_model(self) -> BaseModel:
        """
        找到最佳模型
        
        Returns:
            最佳模型
        """
        best_mae = float('inf')
        
        for name, data in self.models.items():
            if data['metrics']['mae'] < best_mae:
                best_mae = data['metrics']['mae']
                self.best_model = data['model']
                self.best_metrics = data['metrics']
        
        logger.info(f"最佳模型: {self.best_model.model_name}, MAE: {best_mae:.4f}")
        
        return self.best_model
    
    def train_all_models(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series
    ) -> Dict[str, BaseModel]:
        """
        训练所有模型
        
        Args:
            X_train: 训练特征
            y_train: 训练目标
            X_val: 验证特征
            y_val: 验证目标
            
        Returns:
            模型字典
        """
        # LightGBM
        lgb_params = {
            'objective': 'regression',
            'metric': 'mae',
            'num_leaves': 31,
            'learning_rate': 0.05,
            'n_estimators': 100,
            'feature_fraction': 0.8,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'seed': 42,
            'verbose': -1
        }
        lgb_model = LightGBMModel(lgb_params)
        self.train_model(lgb_model, X_train, y_train, X_val, y_val)
        
        # XGBoost
        xgb_params = {
            'objective': 'reg:linear',
            'eval_metric': 'mae',
            'max_depth': 6,
            'learning_rate': 0.05,
            'n_estimators': 100,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'seed': 42
        }
        xgb_model = XGBoostModel(xgb_params)
        self.train_model(xgb_model, X_train, y_train, X_val, y_val)
        
        # 找到最佳模型
        self.find_best_model()
        
        return {name: data['model'] for name, data in self.models.items()}
