"""
模型训练器实现
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
import logging

from .lightgbm_model import LightGBMModel
from .xgboost_model import XGBoostModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ModelTrainer:
    """模型训练器"""
    
    def __init__(self):
        """初始化训练器"""
        self.models = {}
        self.best_model = None
        self.best_metrics = {}
    
    def train_model(
        self,
        model,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series
    ) -> object:
        """
        训练单个模型
        
        Args:
            model: 模型对象
            X_train: 训练特征
            y_train: 训练目标
            X_val: 验证特征
            y_val: 验证目标
            
        Returns:
            训练后的模型
        """
        model.fit(X_train, y_train, X_val, y_val)
        
        # 验证集预测
        y_pred = model.predict(X_val)
        
        # 计算指标
        mae = mean_absolute_error(y_val, y_pred)
        rmse = np.sqrt(mean_squared_error(y_val, y_pred))
        
        logger.info(f"{model.model_name} - Val MAE: {mae:.4f}, RMSE: {rmse:.4f}")
        
        self.models[model.model_name] = {
            'model': model,
            'metrics': {'mae': mae, 'rmse': rmse}
        }
        
        return model
    
    def find_best_model(self) -> object:
        """
        找到最佳模型
        
        Returns:
            最佳模型
        """
        best_mae = float('inf')
        
        for name, data in self.models.items():
            if data['metrics']['mae'] < best_mae:
                best_mae = data['metrics']['mae']
                self.best_model = data['model']
                self.best_metrics = data['metrics']
        
        logger.info(f"最佳模型: {self.best_model.model_name}, MAE: {best_mae:.4f}")
        
        return self.best_model
    
    def train_all_models(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series
    ) -> Dict[str, object]:
        """
        训练所有模型
        
        Args:
            X_train: 训练特征
            y_train: 训练目标
            X_val: 验证特征
            y_val: 验证目标
            
        Returns:
            模型字典
        """
        # LightGBM
        lgb_params = {
            'objective': 'regression',
            'metric': 'mae',
            'num_leaves': 31,
            'learning_rate': 0.05,
            'n_estimators': 100,
            'feature_fraction': 0.8,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'seed': 42,
            'verbose': -1
        }
        lgb_model = LightGBMModel(lgb_params)
        self.train_model(lgb_model, X_train, y_train, X_val, y_val)
        
        # XGBoost
        xgb_params = {
            'objective': 'reg:linear',
            'eval_metric': 'mae',
            'max_depth': 6,
            'learning_rate': 0.05,
            'n_estimators': 100,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'seed': 42
        }
        xgb_model = XGBoostModel(xgb_params)
        self.train_model(xgb_model, X_train, y_train, X_val, y_val)
        
        # 找到最佳模型
        self.find_best_model()
        
        return {name: data['model'] for name, data in self.models.items()}
