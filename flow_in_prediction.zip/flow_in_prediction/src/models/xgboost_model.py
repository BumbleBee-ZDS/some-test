"""
XGBoost模型实现
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
import xgboost as xgb
import logging

from .base_model import BaseModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class XGBoostModel(BaseModel):
    """XGBoost梯度提升树模型"""
    
    def __init__(self, params: Dict = None):
        """
        初始化XGBoost模型
        
        Args:
            params: 模型参数，如果不提供则使用默认参数
        """
        default_params = {
            'objective': 'reg:linear',
            'eval_metric': 'mae',
            'max_depth': 6,
            'learning_rate': 0.05,
            'n_estimators': 100,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'seed': 42
        }
        
        if params:
            default_params.update(params)
        
        super().__init__('XGBoost', default_params)
        self.model = None
    
    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        X_val: pd.DataFrame = None,
        y_val: pd.Series = None
    ) -> 'XGBoostModel':
        """
        训练XGBoost模型
        
        Args:
            X: 训练特征
            y: 训练目标
            X_val: 验证特征（可选）
            y_val: 验证目标（可选）
            
        Returns:
            self
        """
        super().fit(X, y, X_val, y_val)
        
        # 创建DMatrix
        train_matrix = xgb.DMatrix(X, label=y)
        
        # 如果有验证集
        eval_lists = None
        if X_val is not None and y_val is not None:
            val_matrix = xgb.DMatrix(X_val, label=y_val)
            eval_lists = [(train_matrix, 'train'), (val_matrix, 'val')]
        
        # 训练模型
        self.model = xgb.train(
            self.params,
            train_matrix,
            evals=eval_lists,
            verbose_eval=10
        )
        
        self.is_fitted = True
        logger.info(f"XGBoost模型训练完成")
        
        return self
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        预测
        
        Args:
            X: 特征
            
        Returns:
            预测值
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用fit()方法")
        
        dmatrix = xgb.DMatrix(X)
        return self.model.predict(dmatrix)
    
    def get_feature_importance(self) -> pd.DataFrame:
        """
        获取特征重要性
        
        Returns:
            特征重要性DataFrame
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        importance_dict = self.model.get_score(importance_type='weight')
        
        feature_importance = pd.DataFrame([
            {'feature': k, 'importance': v}
            for k, v in importance_dict.items()
        ])
        feature_importance = feature_importance.sort_values('importance', ascending=False)
        
        return feature_importance
