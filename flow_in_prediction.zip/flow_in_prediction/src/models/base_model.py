"""
模型基类
"""

import numpy as np
import pandas as pd
import json
from typing import Dict, List, Optional, Tuple
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BaseModel:
    """模型基类"""
    
    def __init__(self, model_name: str, params: Dict = None):
        """
        初始化模型
        
        Args:
            model_name: 模型名称
            params: 模型参数
        """
        self.model_name = model_name
        self.params = params or {}
        self.model = None
        self.feature_names = None
        self.is_fitted = False
    
    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        X_val: pd.DataFrame = None,
        y_val: pd.Series = None
    ) -> 'BaseModel':
        """
        训练模型
        
        Args:
            X: 训练特征
            y: 训练目标
            X_val: 验证特征（可选）
            y_val: 验证目标（可选）
            
        Returns:
            self
        """
        self.feature_names = X.columns.tolist()
        logger.info(f"开始训练模型: {self.model_name}")
        logger.info(f"训练数据: {X.shape[0]} 样本, {X.shape[1]} 特征")
        
        return self
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        预测
        
        Args:
            X: 特征
            
        Returns:
            预测值
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用fit()方法")
        
        return self.model.predict(X)
    
    def get_feature_importance(self) -> pd.DataFrame:
        """
        获取特征重要性
        
        Returns:
            特征重要性DataFrame
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': self.model.feature_importance_
        })
        importance = importance.sort_values('importance', ascending=False)
        
        return importance
    
    def save(self, filepath: str) -> None:
        """
        保存模型
        
        Args:
            filepath: 保存路径
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练")
        
        model_data = {
            'model_name': self.model_name,
            'params': self.params,
            'feature_names': self.feature_names,
            'is_fitted': self.is_fitted
        }
        
        with open(filepath, 'w') as f:
            json.dump(model_data, f)
        
        logger.info(f"模型已保存到: {filepath}")
    
    def load(self, filepath: str) -> 'BaseModel':
        """
        加载模型
        
        Args:
            filepath: 模型文件路径
            
        Returns:
            self
        """
        with open(filepath, 'r') as f:
            model_data = json.load(f)
        
        self.model_name = model_data['model_name']
        self.params = model_data['params']
        self.feature_names = model_data['feature_names']
        self.is_fitted = model_data['is_fitted']
        
        logger.info(f"模型已加载: {filepath}")
        return self
