"""
Lot到站时间预测系统
"""

from src.main import FlowInPredictor, main

__all__ = ['FlowInPredictor', 'main']
