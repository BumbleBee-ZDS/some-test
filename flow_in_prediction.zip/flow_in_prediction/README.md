# Lot到站时间预测系统

本项目旨在预测特定Lot在特定工艺站点的精确到站时间。

## 项目结构

```
flow_in_prediction/
├── config.yaml                 # 项目配置文件
├── requirements.txt            # Python依赖
├── lot_prediction.py          # 主程序入口
├── example_usage.py           # 使用示例
├── README.md                  # 项目文档
└── src/
    ├── __init__.py
    ├── main.py                # 主程序逻辑
    ├── data/                  # 数据模块
    │   ├── __init__.py
    │   ├── data_loader.py     # 数据加载器
    │   ├── feature_engineer.py # 特征工程
    │   └── preprocessor.py    # 数据预处理
    ├── evaluation/            # 评估模块
    │   ├── __init__.py
    │   └── evaluator.py       # 评估指标和基线模型
    ├── models/                # 模型模块
    │   ├── __init__.py
    │   ├── models.py          # 模型类
    │   ├── base_model.py      # 模型基类
    │   ├── lightgbm_model.py  # LightGBM模型
    │   ├── xgboost_model.py   # XGBoost模型
    │   └── trainer.py         # 模型训练器
    └── visualization/         # 可视化模块
        ├── __init__.py
        └── visualization.py   # 可视化器
```

## 安装依赖

```bash
pip install -r requirements.txt
```

## 配置说明

编辑 `config.yaml` 文件配置数据库连接和模型参数：

```yaml
data:
  database:
    host: "localhost"
    port: 1433
    name: "fab_data"
    user: "sa"
    password: "password"

model:
  ai_models:
    - name: "lightgbm"
      parameters:
        objective: "regression"
        metric: "mae"
        num_leaves: 31
        learning_rate: 0.05
        n_estimators: 100
```

## 使用方法

### 运行预测

```bash
python lot_prediction.py
```

### 使用示例

```bash
python example_usage.py
```

### 自定义参数

```python
from src.main import FlowInPredictor

# 创建预测器
predictor = FlowInPredictor('config.yaml')

# 运行预测
predictor.run(start_date='2024-01-01', end_date='2024-12-31')
```

## 评估指标

系统实现了以下评估指标：

- **MAE** (Mean Absolute Error): 平均绝对误差
- **MSE** (Mean Squared Error): 均方误差
- **RMSE** (Root Mean Squared Error): 均方根误差
- **MAPE** (Mean Absolute Percentage Error): 平均绝对百分比误差
- **SMAPE** (Symmetric Mean Absolute Percentage Error): 对称平均绝对百分比误差

## 特征工程

系统从以下维度提取特征：

1. **Lot基础属性**: 产品型号、工艺路线、优先级、层别、批号大小
2. **历史移动时序**: 历史处理时间、移动节拍
3. **队列状态**: 队列长度、队列工作量、高优先级Lot数
4. **机台状态**: 机台状态、距离上次PM时间、Pi Run计划
5. **Mask管理**: Mask就绪状态、切换时长
6. **特殊派工**: 热批、VIP Lot、实验批标识
7. **时空关系**: 基线预估时间、时间窗口距离

## 输出结果

系统会生成以下输出：

- `results/predictions_comparison.png`: 预测值对比图
- `results/error_distribution.png`: 误差分布图
- `results/metrics_comparison.png`: 评估指标对比图
- `results/time_series_comparison.png`: 时间序列对比图
- `results/feature_importance.png`: 特征重要性图

## 模型选择

系统默认使用LightGBM和XGBoost两种梯度提升树模型，并自动选择表现最佳的模型。

## 数据库表结构

### lot_movement_history
- lot_id: Lot ID
- site: 工艺站点
- product_type: 产品类型
- route: 工艺路线
- priority: 优先级
- layer: 层别
- batch_size: 批号大小
- arrival_timestamp: 到达时间
- departure_timestamp: 离开时间
- hold_duration: 持有时间
- tool_id: 机台ID
- recipe: 配方
- tool_state: 机台状态
- time_since_last_pm: 距上次PM时间

## 注意事项

1. 确保数据库连接配置正确
2. 确保有足够的历史数据进行训练
3. 根据实际业务场景调整特征工程逻辑
4. 定期重新训练模型以保持预测准确性
