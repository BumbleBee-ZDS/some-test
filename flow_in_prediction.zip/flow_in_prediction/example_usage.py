"""
Lot到站时间预测系统使用示例
"""

from src.main import FlowInPredictor

# 创建预测器实例
predictor = FlowInPredictor('config.yaml')

# 运行完整的预测流程
predictor.run()

# 或者自定义参数运行
# predictor.run(start_date='2024-01-01', end_date='2024-12-31')
