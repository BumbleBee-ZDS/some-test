"""
数据加载模块
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DataLoader:
    """数据加载器"""
    
    def __init__(self, db_config: Dict = None):
        """
        初始化数据加载器
        
        Args:
            db_config: 数据库配置
        """
        self.db_config = db_config
        self.data_dir = 'data'
        logger.info("DataLoader初始化完成")
    
    def connect(self):
        """连接数据库（对于CSV数据，此方法为空）"""
        logger.info("连接到CSV数据源")
    
    def close(self):
        """关闭数据库连接（对于CSV数据，此方法为空）"""
        logger.info("关闭CSV数据源连接")
    
    def load_lot_history(self, start_date: str = None, end_date: str = None) -> pd.DataFrame:
        """
        加载Lot移动历史
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            Lot移动历史DataFrame
        """
        csv_path = os.path.join(self.data_dir, 'lot_movement_history.csv')
        
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"数据文件不存在: {csv_path}")
        
        df = pd.read_csv(csv_path, encoding='utf-8-sig')
        
        # 转换时间戳
        df['arrival_timestamp'] = pd.to_datetime(df['arrival_timestamp'])
        df['departure_timestamp'] = pd.to_datetime(df['departure_timestamp'])
        
        # 按日期过滤
        if start_date:
            df = df[df['arrival_timestamp'] >= pd.to_datetime(start_date)]
        if end_date:
            df = df[df['arrival_timestamp'] <= pd.to_datetime(end_date)]
        
        logger.info(f"加载Lot历史数据: {len(df)} 条记录")
        
        return df
    
    def load_queue_state(self) -> pd.DataFrame:
        """加载队列状态数据"""
        csv_path = os.path.join(self.data_dir, 'queue_state.csv')
        
        if not os.path.exists(csv_path):
            logger.warning(f"队列状态文件不存在: {csv_path}")
            return pd.DataFrame()
        
        df = pd.read_csv(csv_path, encoding='utf-8-sig')
        logger.info(f"加载队列状态数据: {len(df)} 条记录")
        
        return df
    
    def load_tool_status(self) -> pd.DataFrame:
        """加载机台状态数据"""
        csv_path = os.path.join(self.data_dir, 'tool_status_history.csv')
        
        if not os.path.exists(csv_path):
            logger.warning(f"机台状态文件不存在: {csv_path}")
            return pd.DataFrame()
        
        df = pd.read_csv(csv_path, encoding='utf-8-sig')
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        logger.info(f"加载机台状态数据: {len(df)} 条记录")
        
        return df
    
    def load_mask_info(self) -> pd.DataFrame:
        """加载Mask管理数据"""
        csv_path = os.path.join(self.data_dir, 'mask_management_history.csv')
        
        if not os.path.exists(csv_path):
            logger.warning(f"Mask管理文件不存在: {csv_path}")
            return pd.DataFrame()
        
        df = pd.read_csv(csv_path, encoding='utf-8-sig')
        df['expected_available_time'] = pd.to_datetime(df['expected_available_time'])
        logger.info(f"加载Mask管理数据: {len(df)} 条记录")
        
        return df
    
    def load_special_dispatch(self) -> pd.DataFrame:
        """加载特殊派工数据"""
        csv_path = os.path.join(self.data_dir, 'special_dispatch_history.csv')
        
        if not os.path.exists(csv_path):
            logger.warning(f"特殊派工文件不存在: {csv_path}")
            return pd.DataFrame()
        
        df = pd.read_csv(csv_path, encoding='utf-8-sig')
        df['dispatch_time'] = pd.to_datetime(df['dispatch_time'])
        logger.info(f"加载特殊派工数据: {len(df)} 条记录")
        
        return df
