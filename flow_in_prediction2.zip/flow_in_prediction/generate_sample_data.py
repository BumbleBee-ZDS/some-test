"""
生成示例数据脚本
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

# 设置随机种子
np.random.seed(42)
random.seed(42)

# 生成Lot移动历史数据
def generate_lot_movement_data(n_lots=100, n_days=90):
    """生成Lot移动历史数据"""
    data = []
    
    # 产品类型和工艺路线
    product_types = ['A', 'B', 'C']
    routes = {
        'A': ['SITE1', 'SITE2', 'SITE3', 'SITE4', 'SITE5'],
        'B': ['SITE1', 'SITE2', 'SITE4', 'SITE5'],
        'C': ['SITE1', 'SITE3', 'SITE5']
    }
    
    start_date = datetime(2024, 1, 1)
    
    for lot_id in range(1, n_lots + 1):
        product_type = random.choice(product_types)
        route = routes[product_type]
        
        # 随机优先级和层别
        priority = random.randint(1, 5)
        layer = random.randint(1, 10)
        batch_size = random.randint(1, 20)
        
        # 随机起始时间
        current_time = start_date + timedelta(days=random.randint(0, n_days-7))
        
        for site in route:
            # 到达时间
            arrival_time = current_time
            
            # 处理时间（基于站点和产品类型）
            base_processing_time = {
                ('SITE1', 'A'): 2.5, ('SITE1', 'B'): 2.0, ('SITE1', 'C'): 3.0,
                ('SITE2', 'A'): 3.0, ('SITE2', 'B'): 2.5, ('SITE2', 'C'): 2.0,
                ('SITE3', 'A'): 1.5, ('SITE3', 'B'): 0, ('SITE3', 'C'): 2.5,
                ('SITE4', 'A'): 2.0, ('SITE4', 'B'): 1.5, ('SITE4', 'C'): 0,
                ('SITE5', 'A'): 1.0, ('SITE5', 'B'): 1.0, ('SITE5', 'C'): 1.5
            }
            
            key = (site, product_type)
            processing_time = base_processing_time.get(key, 2.0)
            # 添加随机波动
            processing_time = max(0.5, processing_time + np.random.normal(0, 0.5))
            
            departure_time = arrival_time + timedelta(hours=processing_time)
            
            # 持有时间（随机挡货）
            hold_duration = 0
            if random.random() < 0.1:  # 10%的概率发生挡货
                hold_duration = random.uniform(1, 8)
                departure_time = departure_time + timedelta(hours=hold_duration)
            
            # 机台状态
            tool_id = f'TOOL_{site[-1]}'
            tool_states = ['production', 'idle', 'maintenance', 'pm']
            tool_state = random.choices(tool_states, weights=[0.7, 0.15, 0.1, 0.05])[0]
            
            # 配方
            recipe = f'RECIPE_{product_type}'
            
            # 距上次PM时间
            time_since_last_pm = random.uniform(10, 200)
            
            data.append({
                'lot_id': f'LOT_{lot_id:04d}',
                'site': site,
                'product_type': product_type,
                'route': '_'.join(route),
                'priority': priority,
                'layer': layer,
                'batch_size': batch_size,
                'arrival_timestamp': arrival_time,
                'departure_timestamp': departure_time,
                'hold_duration': hold_duration,
                'tool_id': tool_id,
                'recipe': recipe,
                'tool_state': tool_state,
                'time_since_last_pm': time_since_last_pm
            })
            
            current_time = departure_time + timedelta(minutes=random.randint(10, 60))
    
    return pd.DataFrame(data)


# 生成队列状态数据
def generate_queue_state_data():
    """生成队列状态数据"""
    data = []
    
    sites = ['SITE1', 'SITE2', 'SITE3', 'SITE4', 'SITE5']
    
    for site in sites:
        n_queue = random.randint(5, 20)
        for i in range(n_queue):
            data.append({
                'lot_id': f'QUEUE_{i:03d}',
                'site': site,
                'priority': random.randint(1, 5),
                'estimated_processing_time': random.uniform(1, 5),
                'hold_status': random.choice(['none', 'hold', 'release']),
                'is_hot_lot': random.choice([0, 1]),
                'is_vip': random.choice([0, 1]),
                'is_eng_lot': random.choice([0, 1])
            })
    
    return pd.DataFrame(data)


# 生成机台状态数据
def generate_tool_status_data():
    """生成机台状态数据"""
    data = []
    
    sites = ['SITE1', 'SITE2', 'SITE3', 'SITE4', 'SITE5']
    tools = ['TOOL_A', 'TOOL_B', 'TOOL_C', 'TOOL_D', 'TOOL_E']
    
    start_date = datetime(2024, 1, 1)
    current_time = start_date
    
    for i in range(1000):
        tool_id = tools[i % 5]
        site = sites[i % 5]
        
        tool_states = ['production', 'idle', 'maintenance', 'pm']
        tool_state = random.choices(tool_states, weights=[0.7, 0.15, 0.1, 0.05])[0]
        
        current_recipe = f'RECIPE_{random.choice(["A", "B", "C"])}'
        time_since_last_pm = random.uniform(10, 200)
        
        pm_schedule = []
        if tool_state == 'pm':
            pm_schedule = [{'start_time': current_time, 'duration': 4}]
        
        data.append({
            'tool_id': tool_id,
            'timestamp': current_time,
            'tool_state': tool_state,
            'current_recipe': current_recipe,
            'time_since_last_pm': time_since_last_pm,
            'pm_schedule': str(pm_schedule)
        })
        
        current_time += timedelta(hours=1)
    
    return pd.DataFrame(data)


# 生成Mask管理数据
def generate_mask_info_data():
    """生成Mask管理数据"""
    data = []
    
    lot_ids = [f'LOT_{i:04d}' for i in range(1, 101)]
    mask_ids = ['MASK_001', 'MASK_002', 'MASK_003', 'MASK_004', 'MASK_005']
    
    for lot_id in lot_ids:
        mask_id = random.choice(mask_ids)
        mask_statuses = ['ready', 'in_use', 'changing']
        mask_status = random.choices(mask_statuses, weights=[0.6, 0.3, 0.1])[0]
        mask_change_duration = random.uniform(0, 2) if mask_status == 'changing' else 0
        
        data.append({
            'lot_id': lot_id,
            'mask_id': mask_id,
            'mask_status': mask_status,
            'mask_change_duration': mask_change_duration,
            'expected_available_time': datetime(2024, 12, 31)
        })
    
    return pd.DataFrame(data)


# 生成特殊派工数据
def generate_special_dispatch_data():
    """生成特殊派工数据"""
    data = []
    
    lot_ids = [f'LOT_{i:04d}' for i in range(1, 101)]
    dispatch_types = ['normal', 'hot_lot', 'vip', 'engineering']
    
    for lot_id in lot_ids:
        dispatch_type = random.choice(dispatch_types)
        priority_weight = random.uniform(1, 3) if dispatch_type != 'normal' else 1
        
        data.append({
            'lot_id': lot_id,
            'dispatch_type': dispatch_type,
            'priority_weight': priority_weight,
            'dispatch_time': datetime(2024, 1, 1) + timedelta(days=random.randint(0, 90)),
            'effective_duration': random.uniform(1, 24)
        })
    
    return pd.DataFrame(data)


# 保存数据到CSV
def save_data():
    """保存所有数据到CSV文件"""
    print("正在生成示例数据...")
    
    # 生成数据
    lot_history = generate_lot_movement_data()
    queue_state = generate_queue_state_data()
    tool_status = generate_tool_status_data()
    mask_info = generate_mask_info_data()
    special_dispatch = generate_special_dispatch_data()
    
    # 保存到CSV
    lot_history.to_csv('data/lot_movement_history.csv', index=False, encoding='utf-8-sig')
    queue_state.to_csv('data/queue_state.csv', index=False, encoding='utf-8-sig')
    tool_status.to_csv('data/tool_status_history.csv', index=False, encoding='utf-8-sig')
    mask_info.to_csv('data/mask_management_history.csv', index=False, encoding='utf-8-sig')
    special_dispatch.to_csv('data/special_dispatch_history.csv', index=False, encoding='utf-8-sig')
    
    print(f"生成的Lot移动历史数据: {len(lot_history)} 条记录")
    print(f"生成的队列状态数据: {len(queue_state)} 条记录")
    print(f"生成的机台状态数据: {len(tool_status)} 条记录")
    print(f"生成的Mask管理数据: {len(mask_info)} 条记录")
    print(f"生成的特殊派工数据: {len(special_dispatch)} 条记录")
    print("\n数据已保存到 data/ 目录")


if __name__ == '__main__':
    save_data()
