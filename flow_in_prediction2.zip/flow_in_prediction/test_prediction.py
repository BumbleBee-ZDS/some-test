"""
测试脚本
"""

from src.main import FlowInPredictor

# 创建预测器实例
predictor = FlowInPredictor()

# 运行预测
predictor.run()
